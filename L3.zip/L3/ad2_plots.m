clear;
close all;
Y = [30.93, 35, 39.12, 43.75, 48.18, 49.25, 50.93]
U = linspace(20,80,7)
figure(1)
scatter(Y, U);

% grid on
% x = [0,25,50,75]';
% y = [u25_z0,u25_z25(i25),u25_z50(i50), u25_z75(i75)]';
% X = [x.^0, x];
% b = (X'*X)\X'*y;
% ym = X*b;
% disp(b)
% figure(2)
% hold on
% scatter([0,25,50,75], [u25_z0,u25_z25(i25), u25_z50(i50), u25_z75(i75)])
% fplot(@(u)b(1) + b(2)*u);
% hold off
